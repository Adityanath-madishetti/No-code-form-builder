# @fluxoris/partner-mfe

Partner-facing Fluxoris integration package for:
- selecting approved workflow templates
- publishing partner form schema versions
- editing template graph in the embedded builder
- connecting published form schema to a Fluxoris workflow
- viewing run/approval details

## What This Package Exports

- `TemplateBuilderFlow`
- `PartnerRunDetailsPage`
- `TemplatePicker`
- `SchemaPublishPanel`
- `TemplateWorkflowBuilder`
- `FlowConnector`
- `RunStatusTimeline`
- `partnerIntegrationApi`

## Install

From a tarball shared by Fluxoris team:

```bash
npm i ./fluxoris-partner-mfe-0.1.1.tgz
```

Or from private registry:

```bash
npm i @fluxoris/partner-mfe
```

## Required Runtime Configuration

Before rendering components, configure API access:

```js
import { partnerIntegrationApi } from '@fluxoris/partner-mfe'

partnerIntegrationApi.configureApiClient({
  baseUrl: 'https://<fluxoris-backend>/api',
  getToken: () => '<fluxoris-access-token>',
  onUnauthorized: () => {
    // trigger host app re-auth/token refresh
  },
})
```

## Authentication Model

All `/api/*` calls from this package require a valid Fluxoris bearer token.

Recommended model:
1. User logs into partner platform.
2. Partner backend calls Fluxoris token exchange endpoint.
3. Partner frontend/MFE uses returned Fluxoris access token.

### Token Exchange API Contract

Endpoint:

`POST /api/auth/partner/exchange`

Request body:

```json
{
  "client_id": "nocode_form_builder",
  "assertion": "<signed-jwt>"
}
```

Assertion requirements:
1. Signed by partner shared secret configured in Fluxoris (`PARTNER_TOKEN_EXCHANGE_CLIENTS_JSON`).
2. `iss` must equal `client_id`.
3. Must include claims: `sub`, `email`, `iat`, `exp`.
4. `aud` must match Fluxoris configured audience (`fluxoris-partner-exchange` by default).

Example assertion payload:

```json
{
  "iss": "nocode_form_builder",
  "sub": "partner-user-123",
  "email": "user@partner.com",
  "name": "Partner User",
  "aud": "fluxoris-partner-exchange",
  "iat": 1777000000,
  "exp": 1777000300
}
```

Response:

```json
{
  "access_token": "<fluxoris-jwt>",
  "token_type": "bearer",
  "provisioned": false,
  "user": {
    "_id": "flux-user-id",
    "email": "user@partner.com",
    "name": "Partner User",
    "picture": "",
    "is_admin": false,
    "created_at": "2026-04-27T12:00:00Z"
  }
}
```

Behavior:
1. If partner identity already linked, same Fluxoris user is used.
2. Else if email exists, identity is linked to that existing user.
3. Else new user is auto-provisioned when enabled.

## Integration Flow (Production)

1. Partner host app obtains Fluxoris token via `/api/auth/partner/exchange`.
2. Configure this package API client (`partnerIntegrationApi.configureApiClient`).
3. Render `TemplateBuilderFlow` with:
   - `formId`
   - `schemaJson` from partner form builder publish model.
4. End user sequence inside MFE:
   - choose approved template (`GET /api/templates?channel=mfe`)
   - publish schema (`POST /api/partner/forms/{form_id}/publish-schema`)
   - edit template graph
   - publish+connect (`POST /api/partner/forms/{form_id}/connect-template`)
5. Store `webhook.path`, `webhook.auth_type`, `webhook.auth_token` from connect response.
6. On real form submission, partner backend posts submission payload to:
   - `POST /webhooks/{webhook_path}`
7. For run details page, render `PartnerRunDetailsPage` or call:
   - `GET /api/partner/forms/runs/{run_id}/audit`

## Important API Endpoints Used By This Package

1. `GET /api/templates?channel=mfe`
2. `GET /api/templates/{template_id}`
3. `GET /api/node-catalog`
4. `POST /api/partner/forms/{form_id}/publish-schema`
5. `GET /api/partner/forms/{form_id}/schema-versions`
6. `POST /api/partner/forms/{form_id}/connect-template`
7. `GET /api/partner/forms/runs/{run_id}/audit?workflow_id=<optional>`

## Example Usage

```jsx
import { TemplateBuilderFlow, partnerIntegrationApi } from '@fluxoris/partner-mfe'
import '@fluxoris/partner-mfe/style.css'

partnerIntegrationApi.configureApiClient({
  baseUrl: 'https://<fluxoris-backend>/api',
  getToken: () => window.currentFluxorisToken,
  onUnauthorized: () => window.location.assign('/login'),
})

export default function PartnerFormIntegrationPage() {
  return (
    <TemplateBuilderFlow
      formId="partner-form-001"
      schemaJson={{
        type: 'object',
        properties: {
          employee_id: { type: 'string' },
          email: { type: 'string', format: 'email' }
        },
        required: ['employee_id', 'email']
      }}
      onConnected={(result) => {
        console.log('Connected:', result.workflow_id, result.webhook?.path)
      }}
    />
  )
}
```

## Production Notes

1. The editable schema textarea shown in local preview pages is demo-only.
2. In production, use your own form builder schema and call `publish-schema` from your publish form flow.
3. Keep partner assertion signing secret in partner backend only.
4. Do not sign assertions in browser/frontend.
5. Token refresh strategy is partner-side responsibility.

## Build and Package (for Fluxoris maintainers)

```bash
npm run build
npm run pack:tgz
```

This generates a distributable `.tgz`.
